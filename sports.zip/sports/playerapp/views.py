from django.shortcuts import render, redirect
from adminapp.models import Event, Score
from .models import Stats, Remarks
from django.contrib.auth.decorators import login_required

@login_required
def playerhomepage(request):
    return render(request, 'playerapp/playerhomepage.html')

from django.shortcuts import render
from adminapp.models import Event, Score

def updated_scores(request):
    scores = Score.objects.all()
    return render(request, 'playerapp/updated_scores.html', {'scores': scores})

def events_without_scores(request):
    events = Event.objects.filter(score__isnull=True)
    return render(request, 'playerapp/events_without_scores.html', {'events': events})

@login_required
def add_stats(request):
    if request.method == 'POST':
        date = request.POST['date']
        score = request.POST['score']
        Stats.objects.create(player=request.user, date=date, score=score)
        return redirect('playerapp:stats')
    return render(request, 'playerapp/add_stats.html')

@login_required
def add_remarks(request):
    if request.method == 'POST':
        date = request.POST['date']
        remark = request.POST['remark']
        Remarks.objects.create(player=request.user, date=date, remark=remark)
        return redirect('playerapp:remarks')
    return render(request, 'playerapp/add_remarks.html')

@login_required
def stats(request):
    stats = Stats.objects.filter(player=request.user)
    return render(request, 'playerapp/stats.html', {'stats': stats})

@login_required
def remarks(request):
    remarks = Remarks.objects.filter(player=request.user)
    return render(request, 'playerapp/remarks.html', {'remarks': remarks})

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Stats, Remarks

@login_required
def player_stats(request):
    player_id = request.user.id
    stats = Stats.objects.filter(player_id=player_id)
    return render(request, 'playerapp/player_stats.html', {'stats': stats})

@login_required
def player_remarks(request):
    player_id = request.user.id
    remarks = Remarks.objects.filter(player_id=player_id)
    return render(request, 'playerapp/player_remarks.html', {'remarks': remarks})