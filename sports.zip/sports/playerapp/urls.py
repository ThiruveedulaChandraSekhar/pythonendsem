from django.urls import path
from . import views

app_name = 'playerapp'
urlpatterns = [
    path('player/', views.playerhomepage, name='playerhomepage'),
   path('updated_scores/', views.updated_scores, name='updated_scores'),
    path('events_without_scores/', views.events_without_scores, name='events_without_scores'),
    path('add_stats/', views.add_stats, name='add_stats'),
    path('add_remarks/', views.add_remarks, name='add_remarks'),
    path('stats/', views.stats, name='stats'),
    path('remarks/', views.remarks, name='remarks'),
    path('player_stats/', views.player_stats, name='player_stats'),
    path('player_remarks/', views.player_remarks, name='player_remarks'),
]