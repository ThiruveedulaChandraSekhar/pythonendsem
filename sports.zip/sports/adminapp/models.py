from django.db import models

# Create your models here.

from django.db import models

class Player(models.Model):
    player_id = models.CharField(max_length=2, unique=True)
    player_name = models.CharField(max_length=100)

    def __str__(self):
        return self.player_name

class Event(models.Model):
    player1 = models.ForeignKey(Player, related_name='player1_events', on_delete=models.CASCADE)
    coach1 = models.CharField(max_length=100)
    player2 = models.ForeignKey(Player, related_name='player2_events', on_delete=models.CASCADE)
    coach2 = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.player1} vs {self.player2}"

class Score(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    player1_round1 = models.IntegerField(default=0)
    player1_round2 = models.IntegerField(default=0)
    player1_round3 = models.IntegerField(default=0)
    player2_round1 = models.IntegerField(default=0)
    player2_round2 = models.IntegerField(default=0)
    player2_round3 = models.IntegerField(default=0)

    def __str__(self):
        return f"Scores for {self.event}"