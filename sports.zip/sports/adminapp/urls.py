from django.urls import path, include
from . import views

urlpatterns = [
    path('',views.projecthomepage,name='projecthomepage'),
    path('loginpagecall/', views.loginpagecall, name='loginpagecall'),
    path('registerpagecall/', views.registerpagecall, name='registerpagecall'),
    path('userloginlogic/', views.userloginlogic, name='userloginlogic'),
    path('userregisterlogic/', views.userregisterlogic, name='userregisterlogic'),
    path('logout/', views.logout, name='logout'),
    path('add_player/', views.add_player, name='add_player'),
    path('add_event/', views.add_event, name='add_event'),
    path('event_list/', views.event_list, name='event_list'),
    path('update_score/<int:event_id>/', views.update_score, name='update_score'),
    path('player_list/', views.player_list, name='player_list'),
]