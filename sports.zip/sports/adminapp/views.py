from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

# Create your views here.
def projecthomepage(request):
    return render(request,'adminapp/projecthomepage.html')


def loginpagecall(request):
    return render(request,'adminapp/loginpage.html')

def registerpagecall(request):
    return render(request,'adminapp/registerpage.html')

from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from django.shortcuts import render

def userregisterlogic(request):
    if request.method == 'POST':
        username = request.POST['username']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        pass1 = request.POST['password']
        pass2 = request.POST['password1']

        if len(username) not in [2, 5]:
            messages.info(request, 'Username must be 2 or 5 characters long.')
            return render(request, 'adminapp/registerpage.html')

        if pass1 == pass2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'OOPS! Username already taken.')
                return render(request, 'adminapp/registerpage.html')
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'OOPS! Email already registered.')
                return render(request, 'adminapp/registerpage.html')
            else:
                user = User.objects.create_user(
                    username=username,
                    password=pass1,
                    first_name=first_name,
                    last_name=last_name,
                    email=email
                )
                user.save()
                messages.info(request, 'Account created Successfully!')
                return render(request, 'adminapp/projecthomepage.html')
        else:
            messages.info(request, 'Passwords do not match.')
            return render(request, 'adminapp/registerpage.html')
    else:
        return render(request, 'adminapp/registerpage.html')

def userloginlogic(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            auth.login(request, user)
            # Check the length of the username
            if len(username) == 5:
                # Redirect to StudentHomePage
                messages.success(request, 'Login successful as viewer!')
                return redirect('userapp:userhomepage')  # Replace with your student homepage URL name
            elif len(username) == 2:
                # Redirect to FacultyHomePage
                messages.success(request, 'Login successful as player!')
                return redirect('playerapp:playerhomepage')  # Replace with your faculty homepage URL name
            else:
                # Invalid username length
                messages.error(request, 'Username length does not match player or user criteria.')
                return render(request, 'adminapp/loginpage.html')
        else:
            # If authentication fails
            messages.error(request, 'Invalid username or password.')
            return render(request, 'adminapp/loginpage.html')
    else:
        return render(request, 'adminapp/loginpage.html')

def logout(request):
    auth.logout(request)
    return redirect('projecthomepage')


from django.shortcuts import render, redirect
from .models import Player, Event, Score

def add_player(request):
    if request.method == 'POST':
        player_id = request.POST['player_id']
        player_name = request.POST['player_name']
        Player.objects.create(player_id=player_id, player_name=player_name)
        messages.success(request, 'Player has been added successfully!')
        return redirect('add_player')
    return render(request, 'adminapp/add_player.html')

def add_event(request):
    players = Player.objects.all()
    if request.method == 'POST':
        player1_id = request.POST['player1']
        coach1 = request.POST['coach1']
        player2_id = request.POST['player2']
        coach2 = request.POST['coach2']
        player1 = Player.objects.get(id=player1_id)
        player2 = Player.objects.get(id=player2_id)
        Event.objects.create(player1=player1, coach1=coach1, player2=player2, coach2=coach2)
        messages.success(request, 'Event has been added successfully!')
        return redirect('add_event')
    return render(request, 'adminapp/add_event.html', {'players': players})

from django.shortcuts import render
from .models import Event

def event_list(request):
    events = Event.objects.filter(score__isnull=True)
    return render(request, 'adminapp/event_list.html', {'events': events})

def update_score(request, event_id):
    event = Event.objects.get(id=event_id)
    if request.method == 'POST':
        score = Score.objects.get_or_create(event=event)[0]
        score.player1_round1 = request.POST['player1_round1']
        score.player1_round2 = request.POST['player1_round2']
        score.player1_round3 = request.POST['player1_round3']
        score.player2_round1 = request.POST['player2_round1']
        score.player2_round2 = request.POST['player2_round2']
        score.player2_round3 = request.POST['player2_round3']
        score.save()
        return redirect('event_list')
    return render(request, 'adminapp/update_score.html', {'event': event})

from django.shortcuts import render
from .models import Player

def player_list(request):
    players = Player.objects.all()
    return render(request, 'adminapp/player_list.html', {'players': players})