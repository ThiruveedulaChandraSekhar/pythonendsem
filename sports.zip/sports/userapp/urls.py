from django.urls import path, include
from . import views
app_name='userapp'
urlpatterns=[
    path('user/', views.userhomepage, name='userhomepage'),
   path('updated_scores/', views.updated_scores, name='updated_scores'),
    path('events_without_scores/', views.events_without_scores, name='events_without_scores'),
]