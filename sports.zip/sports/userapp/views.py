from django.shortcuts import render

# Create your views here.
def userhomepage(request):
    return render(request,'userapp/userhomepage.html')

from django.shortcuts import render
from adminapp.models import Event, Score

def updated_scores(request):
    scores = Score.objects.all()
    return render(request, 'userapp/updated_scores.html', {'scores': scores})

def events_without_scores(request):
    events = Event.objects.filter(score__isnull=True)
    return render(request, 'userapp/events_without_scores.html', {'events': events})